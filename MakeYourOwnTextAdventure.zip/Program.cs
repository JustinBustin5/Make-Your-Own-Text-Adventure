﻿using System;
using System.Reflection;
using System.IO;
using System.Linq;

namespace TATools
{
    class Program : TATools
    {
        static void Main()
        {
            Typewrite("Make Your Own Text Adventure : Beta");
            Typewrite("To begin, type the name of the text adventure you want to play.");
            string TAToLoad = Console.ReadLine().ToLower();
            StartTA(TAToLoad);
        }

        static void StartTA(string TAToLoad)
        {
            string loadFolder;
            loadFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

            Assembly mod = Assembly.LoadFrom(string.Format("{0}\\Mods\\{1}.dll", loadFolder, TAToLoad));
            var result = (from t in mod.GetExportedTypes()
                         where t.GetInterface(typeof(ITextAdventure).Name) != null
                         select mod.CreateInstance(t.FullName, true) as ITextAdventure).ToList();


            if ( result.Count > 1 )
            {
                Typewrite("Multiple text adventures were found in the same mod. This is not allowed.");
                Typewrite("Would you like to run the first one? (y/n)");
                Typewrite("(" + mod.GetExportedTypes()[0].ToString() + ")");
                string yn = Console.ReadLine().ToLower();
                if (yn == "y") { Console.Clear(); result[0].BeginTextAdventure(); }
                else { Console.Clear(); Main(); }
            }
            else
            {
                Console.Clear();
                result[0].BeginTextAdventure();
            }
            


            //Assembly loadedAssembly = null;

            //try { loadedAssembly = Assembly.LoadFrom(string.Format("{0}\\Mods\\{1}.dll", loadFolder, TAToLoad)); }
            //catch { Typewrite("Invalid name. Please retry."); StartTA(Console.ReadLine()); }

            //Type[] tps;
            //ITextAdventure tas;

            //tps = loadedAssembly.GetExportedTypes();
            //for (int i = tps.Length; i > 0; i--)
            //{
            //    var found = tps[tps.Length - i].GetInterface(typeof(ITextAdventure).Name);
            //    var foundt = found.GetType();
            //    tas = loadedAssembly.CreateInstance()

            //    //tas = (ITextAdventure)tps[tps.Length - i].GetInterface(typeof(ITextAdventure).Name);

            //    tas.BeginTextAdventure();
            //    break;
            //}
        }
    }
}