﻿using System;

namespace TATools
{
    public class Class1 : TATools, ITextAdventure
    {
        public Class1()
        {

        }

        public void BeginTextAdventure()
        {
            Typewrite("Welcome to TestTextAdventure.");
            Typewrite("You are trapped in a dungeon.");
            Typewrite("What do you do? A = go to sleep, B = explore");
            Choice1("");
        }

        void Choice1(string currentAction)
        {
            currentAction = Console.ReadLine();
            if (currentAction.ToLower() == "a")
            {
                Typewrite("You go to sleep.");
                Typewrite("...", 500, true);
                Typewrite(" But you don't wake up.");
                Typewrite("The End");
                Console.ReadLine();
            }
            else if (currentAction.ToLower() == "b")
            {
                Typewrite("You explore the dungeon, and find the exit!");
                Typewrite("The End");
                Console.ReadLine();
            }
            else
            {
                Typewrite("Invalid option. Type 'a' to go to sleep, or type 'b' to explore.");
                Choice1("");
            }
        }
    }
}
