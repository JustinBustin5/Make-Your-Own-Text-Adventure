﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace TATools
{
    public class TATools
    {
        public static void Typewrite(string stringToType, int charDelay = 50, bool dontWriteLastAsLine = false)
        {
            bool lastchar = false;
            char[] charsToType = stringToType.ToCharArray();
            for (int i = stringToType.Length; i > 0; i--)
            {
                if (i == 1) lastchar = true;
                else lastchar = false;

                if (!lastchar || lastchar && dontWriteLastAsLine) Console.Write(charsToType[stringToType.Length - i].ToString());
                else if (lastchar && !dontWriteLastAsLine) Console.WriteLine(charsToType[stringToType.Length - i].ToString());

                Thread.Sleep(charDelay);
            }
        }
    }
}