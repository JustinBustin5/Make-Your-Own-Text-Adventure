﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TATools
{
    public interface ITextAdventure
    {
        void BeginTextAdventure();
    }
}
